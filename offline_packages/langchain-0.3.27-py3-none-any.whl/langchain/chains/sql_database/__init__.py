"""Chain for interacting with SQL Database."""
