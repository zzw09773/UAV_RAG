from langchain_community.agents.openai_assistant.base import OpenAIAssistantV2Runnable

__all__ = ["OpenAIAssistantV2Runnable"]
